<?php

namespace Modules\Common\Entities;

use Illuminate\Database\Eloquent\Model;

class Cron extends Model
{
    protected $fillable = [];
}
