<?php

return [
    'name' => 'Common'
];
