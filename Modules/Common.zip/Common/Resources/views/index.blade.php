@extends('common::layouts.master')

@section('home')
active
@endsection
@section('content')
    @include('common::dashboard')
@endsection
