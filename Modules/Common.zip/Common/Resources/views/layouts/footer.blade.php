<!-- ============================================================== -->
<!-- footer -->
<!-- ============================================================== -->
<div class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                {{ settingHelper('copyright_text') }}
                {{-- {{ \Carbon\Carbon::now()->year }}   --}}
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                <div class="text-md-right footer-links d-none d-sm-block">
                    <a href="javascript: void(0);">{{__('about')}}</a>
                    <a href="javascript: void(0);">{{__('support')}}</a>
                    <a href="javascript: void(0);">{{__('contact_us')}}</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ============================================================== -->
<!-- end footer -->
<!-- ============================================================== -->